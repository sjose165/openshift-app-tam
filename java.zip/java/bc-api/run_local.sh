#!/usr/bin/bash
./mvnw package && java -jar target/poc-0.0.1-SNAPSHOT.jar